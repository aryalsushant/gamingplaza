﻿namespace Gaming_final
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.strartgamebut = new System.Windows.Forms.Button();
            this.Charactersumlabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.StatsgroupBox = new System.Windows.Forms.GroupBox();
            this.defenselabel = new System.Windows.Forms.Label();
            this.speedlabel = new System.Windows.Forms.Label();
            this.Attacklabel = new System.Windows.Forms.Label();
            this.healthlabel = new System.Windows.Forms.Label();
            this.powerupaddonlabel = new System.Windows.Forms.Label();
            this.StatsgroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // strartgamebut
            // 
            this.strartgamebut.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.strartgamebut.Location = new System.Drawing.Point(618, 383);
            this.strartgamebut.Name = "strartgamebut";
            this.strartgamebut.Size = new System.Drawing.Size(146, 36);
            this.strartgamebut.TabIndex = 13;
            this.strartgamebut.Text = "Start Game";
            this.strartgamebut.UseVisualStyleBackColor = true;
            // 
            // Charactersumlabel
            // 
            this.Charactersumlabel.AutoSize = true;
            this.Charactersumlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Charactersumlabel.Location = new System.Drawing.Point(252, 38);
            this.Charactersumlabel.Name = "Charactersumlabel";
            this.Charactersumlabel.Size = new System.Drawing.Size(311, 37);
            this.Charactersumlabel.TabIndex = 14;
            this.Charactersumlabel.Text = "Character Summary: \r\n";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(404, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 31);
            this.label1.TabIndex = 15;
            this.label1.Text = "Avatar Type:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // StatsgroupBox
            // 
            this.StatsgroupBox.Controls.Add(this.defenselabel);
            this.StatsgroupBox.Controls.Add(this.speedlabel);
            this.StatsgroupBox.Controls.Add(this.Attacklabel);
            this.StatsgroupBox.Controls.Add(this.healthlabel);
            this.StatsgroupBox.Location = new System.Drawing.Point(12, 90);
            this.StatsgroupBox.Name = "StatsgroupBox";
            this.StatsgroupBox.Size = new System.Drawing.Size(359, 298);
            this.StatsgroupBox.TabIndex = 16;
            this.StatsgroupBox.TabStop = false;
            // 
            // defenselabel
            // 
            this.defenselabel.AutoSize = true;
            this.defenselabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.defenselabel.Location = new System.Drawing.Point(7, 154);
            this.defenselabel.Name = "defenselabel";
            this.defenselabel.Size = new System.Drawing.Size(303, 27);
            this.defenselabel.TabIndex = 7;
            this.defenselabel.Text = "Defense (Armor/Resistance):";
            // 
            // speedlabel
            // 
            this.speedlabel.AutoSize = true;
            this.speedlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.speedlabel.Location = new System.Drawing.Point(7, 223);
            this.speedlabel.Name = "speedlabel";
            this.speedlabel.Size = new System.Drawing.Size(287, 27);
            this.speedlabel.TabIndex = 8;
            this.speedlabel.Text = "Speed (Agility/Movement):";
            // 
            // Attacklabel
            // 
            this.Attacklabel.AutoSize = true;
            this.Attacklabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Attacklabel.Location = new System.Drawing.Point(6, 88);
            this.Attacklabel.Name = "Attacklabel";
            this.Attacklabel.Size = new System.Drawing.Size(286, 27);
            this.Attacklabel.TabIndex = 6;
            this.Attacklabel.Text = "Attack (Strength/Damage):";
            // 
            // healthlabel
            // 
            this.healthlabel.AutoSize = true;
            this.healthlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.healthlabel.Location = new System.Drawing.Point(7, 18);
            this.healthlabel.Name = "healthlabel";
            this.healthlabel.Size = new System.Drawing.Size(136, 27);
            this.healthlabel.TabIndex = 5;
            this.healthlabel.Text = "Health (HP):";
            // 
            // powerupaddonlabel
            // 
            this.powerupaddonlabel.AutoSize = true;
            this.powerupaddonlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.powerupaddonlabel.Location = new System.Drawing.Point(404, 257);
            this.powerupaddonlabel.Name = "powerupaddonlabel";
            this.powerupaddonlabel.Size = new System.Drawing.Size(236, 31);
            this.powerupaddonlabel.TabIndex = 17;
            this.powerupaddonlabel.Text = "Power-up Add ons:";
            this.powerupaddonlabel.Click += new System.EventHandler(this.powerupaddonlabel_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.powerupaddonlabel);
            this.Controls.Add(this.StatsgroupBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Charactersumlabel);
            this.Controls.Add(this.strartgamebut);
            this.Name = "Form5";
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.StatsgroupBox.ResumeLayout(false);
            this.StatsgroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button strartgamebut;
        private System.Windows.Forms.Label Charactersumlabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox StatsgroupBox;
        private System.Windows.Forms.Label defenselabel;
        private System.Windows.Forms.Label speedlabel;
        private System.Windows.Forms.Label Attacklabel;
        private System.Windows.Forms.Label healthlabel;
        private System.Windows.Forms.Label powerupaddonlabel;
    }
}