﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gaming_final
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void StoryModebutton_Click(object sender, EventArgs e)
        {
            Form2 storyForm = new Form2();
            storyForm.Show();
            this.Hide();
        }

        private void Onlinemodebutton_Click(object sender, EventArgs e)
        {
            Form3 onlineForm = new Form3();
            onlineForm.Show();
            this.Hide();
        }
        private void frm_menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
