﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gaming_final
{
    public partial class Form2 : Form
    {
        int warriorHealth = 80;
        int warriorAttack = 70;
        int warriorDefense = 70; 
        int warriorSpeed = 40;
        int mageHealth = 40;
        int mageAttack = 90;
        int mageDefense = 60;
        int mageSpeed = 50;
        string powerAddons = "";

        public Form2()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void WarriorradioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (WarriorradioButton.Checked)
            {
                descriptionlabel.Text = "Warrior: \nA strong and \nresilient \nfighter, \nexcelling in \nmelee combat.";
                label2.Text = "Health (HP): " + warriorHealth.ToString();
                Attacklabel.Text = "Attack (Strength/Damage): " + warriorAttack.ToString();
                defenselabel.Text = "Defense (Armor/Resistance): " + warriorAttack.ToString(); 
                speedlabel.Text = "Speed (Agility/Movement): " + warriorSpeed.ToString();
            }
        
        }

        private void MageradioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (MageradioButton.Checked)
            {
                descriptionlabel.Text = "Mage: Mage: \nA spellcaster \nwho uses \nmagic \nto attack or \nsupport allies.";
                label2.Text = "Health (HP): " + mageHealth.ToString();
                Attacklabel.Text = "Attack (Strength/Damage): " + mageAttack.ToString(); ;
                defenselabel.Text = "Defense (Armor/Resistance): " + mageDefense.ToString(); ;
                speedlabel.Text = "Speed (Agility/Movement): " + mageSpeed.ToString();
            }
        }

        private void continuebutton_Click(object sender, EventArgs e)
        {
            int health = warriorHealth;
            int attack = warriorAttack;
            int defense = warriorDefense;
            int speed = warriorSpeed;

            string avatarName = "Warrior"; 

            if (MageradioButton.Checked)
            {
                health = mageHealth;
                attack = mageAttack;
                defense = mageDefense;
                speed = mageSpeed;
                avatarName = "Mage";
            }

            Form4 nextForm = new Form4(avatarName, health, attack, defense, speed, powerAddons );
            nextForm.Show();
            this.Hide();
        }

        private void frm_menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
