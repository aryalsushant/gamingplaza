﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Gaming_final.Form4;

namespace Gaming_final
{
    public partial class Form4 : Form
    {
        private string avatarName;
        private int health;
        private int attack;
        private int defense;
        private int speed;
        private string powerAddons;

        public Form4(string avatar, int health, int attack, int defense, int speed, string powerAddons)
        {
            InitializeComponent();

            this.avatarName = avatar;
            this.health = health;
            this.attack = attack;
            this.defense = defense;
            this.speed = speed;
            this.powerAddons = powerAddons;
        }

        private void attackenhancementcheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (attackenhancementcheckBox.Checked)
            {
                attack += 9;
                if (!powerAddons.Contains("Attack Enhancement"))
                {
                    powerAddons += "Attack Enhancement ";
                }
            }
            else
            {
                attack -= 9;
                powerAddons = powerAddons.Replace("Attack Enhancement ","");
            }
        }

        private void speedboostcheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (speedboostcheckBox.Checked)
            {
                speed += 5;
                if (!powerAddons.Contains("Speed Boost"))
                {
                    powerAddons += "Speed Boost ";
                }
            }
            else
            {
                speed -= 5;
                powerAddons = powerAddons.Replace("Speed Boost ", "");
            }
        }

        private void defensebuffcheckbox_CheckedChanged(object sender, EventArgs e)
        {
            if (defensebuffcheckbox.Checked)
            {
                defense += 25;
                if (!powerAddons.Contains("Defense Buff"))
                {
                    powerAddons += "Defense Buff ";
                }
            }
            else
            {
                defense -= 25;
                powerAddons = powerAddons.Replace("Defense Buff ", "");
            }
        }

        private void powerupcheckbox_CheckedChanged(object sender, EventArgs e)
        {
            if (powerupcheckbox.Checked)
            {
                attack += 10; 
                if (!powerAddons.Contains("Power-Up"))
                {
                    powerAddons += "Power-Up ";
                }
            }
            else
            {
                attack -= 10;
                powerAddons = powerAddons.Replace("Power-Up ", "");
            }
        }

        private void replenishmentcheckbox_CheckedChanged(object sender, EventArgs e)
        {
            if (replenishmentcheckbox.Checked)
            {
                health += 20;
                if (!powerAddons.Contains("Replenishment"))
                {
                    powerAddons += ("Replenishment ");
                }
            }
            else
            {
                health -= 20;
                powerAddons = powerAddons.Replace("Replenishment ", "");
            }
        }

        private void healthboostcheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (healthboostcheckBox.Checked)
            {
                health += 30;
                if (!powerAddons.Contains("Health Boost"))
                {
                    powerAddons += "Health Boost ";
                }
            }
            else
            {
                health -= 30;
                powerAddons = powerAddons.Replace("Health Boost ", "");
            }
        }

        private void continuebutton_Click(object sender, EventArgs e)
        {
            powerAddons = powerAddons.TrimEnd(',', ' ');
            Form5 nextForm = new Form5(avatarName, health, attack, defense, speed,powerAddons);
            nextForm.Show();
            this.Hide(); 
      
        }

        private void frm_menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
