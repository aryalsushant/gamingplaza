﻿namespace Gaming_final
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SelectAvatarLabel = new System.Windows.Forms.Label();
            this.StatsgroupBox = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Attacklabel = new System.Windows.Forms.Label();
            this.defenselabel = new System.Windows.Forms.Label();
            this.speedlabel = new System.Windows.Forms.Label();
            this.descriptiongroupBox = new System.Windows.Forms.GroupBox();
            this.descriptionlabel = new System.Windows.Forms.Label();
            this.continuebutton = new System.Windows.Forms.Button();
            this.WarriorradioButton = new System.Windows.Forms.RadioButton();
            this.MageradioButton = new System.Windows.Forms.RadioButton();
            this.StatsgroupBox.SuspendLayout();
            this.descriptiongroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // SelectAvatarLabel
            // 
            this.SelectAvatarLabel.AutoSize = true;
            this.SelectAvatarLabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectAvatarLabel.Location = new System.Drawing.Point(244, 27);
            this.SelectAvatarLabel.Name = "SelectAvatarLabel";
            this.SelectAvatarLabel.Size = new System.Drawing.Size(275, 37);
            this.SelectAvatarLabel.TabIndex = 2;
            this.SelectAvatarLabel.Text = "Select Your Avatar";
            // 
            // StatsgroupBox
            // 
            this.StatsgroupBox.Controls.Add(this.defenselabel);
            this.StatsgroupBox.Controls.Add(this.speedlabel);
            this.StatsgroupBox.Controls.Add(this.Attacklabel);
            this.StatsgroupBox.Controls.Add(this.label2);
            this.StatsgroupBox.Location = new System.Drawing.Point(416, 119);
            this.StatsgroupBox.Name = "StatsgroupBox";
            this.StatsgroupBox.Size = new System.Drawing.Size(358, 298);
            this.StatsgroupBox.TabIndex = 3;
            this.StatsgroupBox.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 27);
            this.label2.TabIndex = 5;
            this.label2.Text = "Health (HP):";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Attacklabel
            // 
            this.Attacklabel.AutoSize = true;
            this.Attacklabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Attacklabel.Location = new System.Drawing.Point(6, 88);
            this.Attacklabel.Name = "Attacklabel";
            this.Attacklabel.Size = new System.Drawing.Size(286, 27);
            this.Attacklabel.TabIndex = 6;
            this.Attacklabel.Text = "Attack (Strength/Damage):";
            // 
            // defenselabel
            // 
            this.defenselabel.AutoSize = true;
            this.defenselabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.defenselabel.Location = new System.Drawing.Point(7, 154);
            this.defenselabel.Name = "defenselabel";
            this.defenselabel.Size = new System.Drawing.Size(303, 27);
            this.defenselabel.TabIndex = 7;
            this.defenselabel.Text = "Defense (Armor/Resistance):";
            // 
            // speedlabel
            // 
            this.speedlabel.AutoSize = true;
            this.speedlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.speedlabel.Location = new System.Drawing.Point(7, 223);
            this.speedlabel.Name = "speedlabel";
            this.speedlabel.Size = new System.Drawing.Size(287, 27);
            this.speedlabel.TabIndex = 8;
            this.speedlabel.Text = "Speed (Agility/Movement):";
            // 
            // descriptiongroupBox
            // 
            this.descriptiongroupBox.Controls.Add(this.descriptionlabel);
            this.descriptiongroupBox.Location = new System.Drawing.Point(227, 119);
            this.descriptiongroupBox.Name = "descriptiongroupBox";
            this.descriptiongroupBox.Size = new System.Drawing.Size(183, 298);
            this.descriptiongroupBox.TabIndex = 5;
            this.descriptiongroupBox.TabStop = false;
            // 
            // descriptionlabel
            // 
            this.descriptionlabel.AutoSize = true;
            this.descriptionlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descriptionlabel.Location = new System.Drawing.Point(6, 18);
            this.descriptionlabel.Name = "descriptionlabel";
            this.descriptionlabel.Size = new System.Drawing.Size(133, 27);
            this.descriptionlabel.TabIndex = 6;
            this.descriptionlabel.Text = "Description:";
            // 
            // continuebutton
            // 
            this.continuebutton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.continuebutton.Location = new System.Drawing.Point(608, 33);
            this.continuebutton.Name = "continuebutton";
            this.continuebutton.Size = new System.Drawing.Size(134, 36);
            this.continuebutton.TabIndex = 6;
            this.continuebutton.Text = "Continue";
            this.continuebutton.UseVisualStyleBackColor = true;
            this.continuebutton.Click += new System.EventHandler(this.continuebutton_Click);
            // 
            // WarriorradioButton
            // 
            this.WarriorradioButton.AutoSize = true;
            this.WarriorradioButton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WarriorradioButton.Location = new System.Drawing.Point(12, 207);
            this.WarriorradioButton.Name = "WarriorradioButton";
            this.WarriorradioButton.Size = new System.Drawing.Size(190, 31);
            this.WarriorradioButton.TabIndex = 7;
            this.WarriorradioButton.TabStop = true;
            this.WarriorradioButton.Text = "Warrior/Fighter";
            this.WarriorradioButton.UseVisualStyleBackColor = true;
            this.WarriorradioButton.CheckedChanged += new System.EventHandler(this.WarriorradioButton_CheckedChanged);
            // 
            // MageradioButton
            // 
            this.MageradioButton.AutoSize = true;
            this.MageradioButton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MageradioButton.Location = new System.Drawing.Point(12, 269);
            this.MageradioButton.Name = "MageradioButton";
            this.MageradioButton.Size = new System.Drawing.Size(171, 31);
            this.MageradioButton.TabIndex = 8;
            this.MageradioButton.TabStop = true;
            this.MageradioButton.Text = "Mage/Wizard";
            this.MageradioButton.UseVisualStyleBackColor = true;
            this.MageradioButton.CheckedChanged += new System.EventHandler(this.MageradioButton_CheckedChanged);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.MageradioButton);
            this.Controls.Add(this.WarriorradioButton);
            this.Controls.Add(this.continuebutton);
            this.Controls.Add(this.descriptiongroupBox);
            this.Controls.Add(this.StatsgroupBox);
            this.Controls.Add(this.SelectAvatarLabel);
            this.Name = "Form2";
            this.Text = "Form2";
            this.StatsgroupBox.ResumeLayout(false);
            this.StatsgroupBox.PerformLayout();
            this.descriptiongroupBox.ResumeLayout(false);
            this.descriptiongroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SelectAvatarLabel;
        private System.Windows.Forms.GroupBox StatsgroupBox;
        private System.Windows.Forms.Label Attacklabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label defenselabel;
        private System.Windows.Forms.Label speedlabel;
        private System.Windows.Forms.GroupBox descriptiongroupBox;
        private System.Windows.Forms.Label descriptionlabel;
        private System.Windows.Forms.Button continuebutton;
        private System.Windows.Forms.RadioButton WarriorradioButton;
        private System.Windows.Forms.RadioButton MageradioButton;
    }
}