﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gaming_final
{
    public partial class Form5 : Form
    {
        private string avatarName;
        private int health;
        private int attack;
        private int defense;
        private int speed;
        private string powerAddons;

        public Form5(string avatar, int health, int attack, int defense, int speed,string powerAddons)
        {
            this.avatarName = avatar;
            this.health = health;
            this.attack = attack;
            this.defense = defense;
            this.speed = speed;
            this.powerAddons = powerAddons;
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void frm_menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void powerupaddonlabel_Click(object sender, EventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            label1.Text = "Avatar Type:" + avatarName;
            healthlabel.Text = "Health (HP): " + health;
            Attacklabel.Text = "Attack (Strength/Damage): " + attack;
            defenselabel.Text = "Defense (Armor/Resistance): " + defense;
            speedlabel.Text = "Speed (Agility/Movement): " + speed;

            if (!string.IsNullOrEmpty(powerAddons))
            {
                powerupaddonlabel.Text = "Power-Up Add-Ons: " + powerAddons; 
            }
            else
            {
                powerupaddonlabel.Text = "Power-Up Add-Ons: None";
            }
        }
    }
}
