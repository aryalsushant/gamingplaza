﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gaming_final
{
    public partial class Form3 : Form
    {
        int warriorHealth = 80;
        int warriorAttack = 70;
        int warriorDefense = 70;
        int warriorSpeed = 40;
        int mageHealth = 40;
        int mageAttack = 90;
        int mageDefense = 60;
        int mageSpeed = 50;
        int rogueHealth = 60;
        int rogueAttack = 80;
        int rogueDefense = 50;
        int rogueSpeed = 100;
        int healerHealth = 50;
        int healerAttack = 40;
        int healerDefense = 90;
        int healerSpeed = 60;
        string powerAddons = "";
        public Form3()
        {
            InitializeComponent();
        }

        private void WarriorradioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (WarriorradioButton.Checked)
            {
                descriptionlabel.Text = "Warrior: \nA strong and \nresilient \nfighter, \nexcelling\n in \nmelee \ncombat.";
                label2.Text = "Health (HP) : " + warriorHealth.ToString();
                Attacklabel.Text = "Attack (Strength/Damage): " + warriorAttack.ToString(); 
                defenselabel.Text = "Defense (Armor/Resistance): " + warriorAttack.ToString(); 
                speedlabel.Text = "Speed (Agility/Movement): " + warriorSpeed.ToString();
            }
        }

        private void MageradioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (MageradioButton.Checked)
            {
                descriptionlabel.Text = "Mage: \nA spellcaster \nwho uses \nmagic \nto attack or \nsupport \nallies.";
                label2.Text = "Health (HP): " + mageHealth.ToString();
                Attacklabel.Text = "Attack (Strength/Damage): " + mageAttack.ToString(); 
                defenselabel.Text = "Defense (Armor/Resistance): " + mageDefense.ToString(); 
                speedlabel.Text = "Speed (Agility/Movement): " + mageSpeed.ToString();
            }
        }

        private void rogueradioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (rogueradioButton.Checked)
            {
                descriptionlabel.Text = "Rogue: \nA stealthy \nand agile \navatar \nthat excels in quick, \nprecise \nattacks.";
                label2.Text = "Health (HP): " + rogueHealth.ToString();
                Attacklabel.Text = "Attack (Strength/Damage): " + rogueAttack.ToString(); 
                defenselabel.Text = "Defense (Armor/Resistance): " + rogueDefense.ToString(); 
                speedlabel.Text = "Speed (Agility/Movement): " + rogueSpeed.ToString();
            }
        }

        private void healerradioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (healerradioButton.Checked)
            {
                descriptionlabel.Text = "Healer: \nFocuses on \naiding allies \nby restoring \nhealth, \nbuffing stats, \nor removing \nnegative \neffects.";
                label2.Text = "Health (HP): " + healerHealth.ToString();
                Attacklabel.Text = "Attack (Strength/Damage): " + healerAttack.ToString(); 
                defenselabel.Text = "Defense (Armor/Resistance): " + healerDefense.ToString(); 
                speedlabel.Text = "Speed (Agility/Movement): " + healerSpeed.ToString();
            }
        }

        private void continuebutton_Click(object sender, EventArgs e)
        {
            int health = 0, attack = 0, defense = 0, speed = 0;
            string avatarName = "";

            if (WarriorradioButton.Checked)
            {
                health = warriorHealth;
                attack = warriorAttack;
                defense = warriorDefense;
                speed = warriorSpeed;
                avatarName = "Warrior";
            }
            else if (MageradioButton.Checked)
            {
                health = mageHealth;
                attack = mageAttack;
                defense = mageDefense;
                speed = mageSpeed;
                avatarName = "Mage";
            }
            else if (rogueradioButton.Checked)
            {
                health = rogueHealth;
                attack = rogueAttack;
                defense = rogueDefense;
                speed = rogueSpeed;
                avatarName = "Rogue";
            }
            else if (healerradioButton.Checked)
            {
                health = healerHealth;
                attack = healerAttack;
                defense = healerDefense;
                speed = healerSpeed;
                avatarName = "Healer";
            }

            Form4 nextForm = new Form4(avatarName, health, attack, defense, speed, powerAddons);
            nextForm.Show();
            this.Hide();
        }

        private void frm_menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
