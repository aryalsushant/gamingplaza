﻿namespace Gaming_final
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addonlabel = new System.Windows.Forms.Label();
            this.healthboostcheckBox = new System.Windows.Forms.CheckBox();
            this.attackenhancementcheckBox = new System.Windows.Forms.CheckBox();
            this.speedboostcheckBox = new System.Windows.Forms.CheckBox();
            this.defensebuffcheckbox = new System.Windows.Forms.CheckBox();
            this.powerupcheckbox = new System.Windows.Forms.CheckBox();
            this.replenishmentcheckbox = new System.Windows.Forms.CheckBox();
            this.continuebutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // addonlabel
            // 
            this.addonlabel.AutoSize = true;
            this.addonlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addonlabel.Location = new System.Drawing.Point(236, 33);
            this.addonlabel.Name = "addonlabel";
            this.addonlabel.Size = new System.Drawing.Size(274, 37);
            this.addonlabel.TabIndex = 10;
            this.addonlabel.Text = "Power-Up Add On";
            // 
            // healthboostcheckBox
            // 
            this.healthboostcheckBox.AutoSize = true;
            this.healthboostcheckBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.healthboostcheckBox.Location = new System.Drawing.Point(606, 290);
            this.healthboostcheckBox.Name = "healthboostcheckBox";
            this.healthboostcheckBox.Size = new System.Drawing.Size(165, 31);
            this.healthboostcheckBox.TabIndex = 11;
            this.healthboostcheckBox.Text = "Health Boost";
            this.healthboostcheckBox.UseVisualStyleBackColor = true;
            this.healthboostcheckBox.CheckedChanged += new System.EventHandler(this.healthboostcheckBox_CheckedChanged);
            // 
            // attackenhancementcheckBox
            // 
            this.attackenhancementcheckBox.AutoSize = true;
            this.attackenhancementcheckBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attackenhancementcheckBox.Location = new System.Drawing.Point(12, 139);
            this.attackenhancementcheckBox.Name = "attackenhancementcheckBox";
            this.attackenhancementcheckBox.Size = new System.Drawing.Size(242, 31);
            this.attackenhancementcheckBox.TabIndex = 12;
            this.attackenhancementcheckBox.Text = "Attack Enhancement";
            this.attackenhancementcheckBox.UseVisualStyleBackColor = true;
            this.attackenhancementcheckBox.CheckedChanged += new System.EventHandler(this.attackenhancementcheckBox_CheckedChanged);
            // 
            // speedboostcheckBox
            // 
            this.speedboostcheckBox.AutoSize = true;
            this.speedboostcheckBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.speedboostcheckBox.Location = new System.Drawing.Point(314, 139);
            this.speedboostcheckBox.Name = "speedboostcheckBox";
            this.speedboostcheckBox.Size = new System.Drawing.Size(160, 31);
            this.speedboostcheckBox.TabIndex = 13;
            this.speedboostcheckBox.Text = "Speed Boost";
            this.speedboostcheckBox.UseVisualStyleBackColor = true;
            this.speedboostcheckBox.CheckedChanged += new System.EventHandler(this.speedboostcheckBox_CheckedChanged);
            // 
            // defensebuffcheckbox
            // 
            this.defensebuffcheckbox.AutoSize = true;
            this.defensebuffcheckbox.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.defensebuffcheckbox.Location = new System.Drawing.Point(606, 139);
            this.defensebuffcheckbox.Name = "defensebuffcheckbox";
            this.defensebuffcheckbox.Size = new System.Drawing.Size(166, 31);
            this.defensebuffcheckbox.TabIndex = 14;
            this.defensebuffcheckbox.Text = "Defense Buff";
            this.defensebuffcheckbox.UseVisualStyleBackColor = true;
            this.defensebuffcheckbox.CheckedChanged += new System.EventHandler(this.defensebuffcheckbox_CheckedChanged);
            // 
            // powerupcheckbox
            // 
            this.powerupcheckbox.AutoSize = true;
            this.powerupcheckbox.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.powerupcheckbox.Location = new System.Drawing.Point(12, 290);
            this.powerupcheckbox.Name = "powerupcheckbox";
            this.powerupcheckbox.Size = new System.Drawing.Size(280, 31);
            this.powerupcheckbox.TabIndex = 15;
            this.powerupcheckbox.Text = "Special Ability Power-up";
            this.powerupcheckbox.UseVisualStyleBackColor = true;
            this.powerupcheckbox.CheckedChanged += new System.EventHandler(this.powerupcheckbox_CheckedChanged);
            // 
            // replenishmentcheckbox
            // 
            this.replenishmentcheckbox.AutoSize = true;
            this.replenishmentcheckbox.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.replenishmentcheckbox.Location = new System.Drawing.Point(314, 290);
            this.replenishmentcheckbox.Name = "replenishmentcheckbox";
            this.replenishmentcheckbox.Size = new System.Drawing.Size(260, 31);
            this.replenishmentcheckbox.TabIndex = 16;
            this.replenishmentcheckbox.Text = "Energy Replenishment";
            this.replenishmentcheckbox.UseVisualStyleBackColor = true;
            this.replenishmentcheckbox.CheckedChanged += new System.EventHandler(this.replenishmentcheckbox_CheckedChanged);
            // 
            // continuebutton
            // 
            this.continuebutton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.continuebutton.Location = new System.Drawing.Point(586, 33);
            this.continuebutton.Name = "continuebutton";
            this.continuebutton.Size = new System.Drawing.Size(165, 36);
            this.continuebutton.TabIndex = 17;
            this.continuebutton.Text = "Continue";
            this.continuebutton.UseVisualStyleBackColor = true;
            this.continuebutton.Click += new System.EventHandler(this.continuebutton_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.continuebutton);
            this.Controls.Add(this.replenishmentcheckbox);
            this.Controls.Add(this.powerupcheckbox);
            this.Controls.Add(this.defensebuffcheckbox);
            this.Controls.Add(this.speedboostcheckBox);
            this.Controls.Add(this.attackenhancementcheckBox);
            this.Controls.Add(this.healthboostcheckBox);
            this.Controls.Add(this.addonlabel);
            this.Name = "Form4";
            this.Text = "Form4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label addonlabel;
        private System.Windows.Forms.CheckBox healthboostcheckBox;
        private System.Windows.Forms.CheckBox attackenhancementcheckBox;
        private System.Windows.Forms.CheckBox speedboostcheckBox;
        private System.Windows.Forms.CheckBox defensebuffcheckbox;
        private System.Windows.Forms.CheckBox powerupcheckbox;
        private System.Windows.Forms.CheckBox replenishmentcheckbox;
        private System.Windows.Forms.Button continuebutton;
    }
}