﻿namespace Gaming_final
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WelcomeLabel = new System.Windows.Forms.Label();
            this.Oneoptionlabel = new System.Windows.Forms.Label();
            this.StoryModebutton = new System.Windows.Forms.Button();
            this.Onlinemodebutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // WelcomeLabel
            // 
            this.WelcomeLabel.AutoSize = true;
            this.WelcomeLabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WelcomeLabel.Location = new System.Drawing.Point(303, 34);
            this.WelcomeLabel.Name = "WelcomeLabel";
            this.WelcomeLabel.Size = new System.Drawing.Size(157, 37);
            this.WelcomeLabel.TabIndex = 0;
            this.WelcomeLabel.Text = "Welcome!";
            // 
            // Oneoptionlabel
            // 
            this.Oneoptionlabel.AutoSize = true;
            this.Oneoptionlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Oneoptionlabel.Location = new System.Drawing.Point(179, 71);
            this.Oneoptionlabel.Name = "Oneoptionlabel";
            this.Oneoptionlabel.Size = new System.Drawing.Size(380, 37);
            this.Oneoptionlabel.TabIndex = 1;
            this.Oneoptionlabel.Text = "Please choose one option.";
            // 
            // StoryModebutton
            // 
            this.StoryModebutton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StoryModebutton.Location = new System.Drawing.Point(287, 149);
            this.StoryModebutton.Name = "StoryModebutton";
            this.StoryModebutton.Size = new System.Drawing.Size(173, 62);
            this.StoryModebutton.TabIndex = 2;
            this.StoryModebutton.Text = "Story Mode";
            this.StoryModebutton.UseVisualStyleBackColor = true;
            this.StoryModebutton.Click += new System.EventHandler(this.StoryModebutton_Click);
            // 
            // Onlinemodebutton
            // 
            this.Onlinemodebutton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Onlinemodebutton.Location = new System.Drawing.Point(287, 272);
            this.Onlinemodebutton.Name = "Onlinemodebutton";
            this.Onlinemodebutton.Size = new System.Drawing.Size(173, 62);
            this.Onlinemodebutton.TabIndex = 3;
            this.Onlinemodebutton.Text = "Online Mode";
            this.Onlinemodebutton.UseVisualStyleBackColor = true;
            this.Onlinemodebutton.Click += new System.EventHandler(this.Onlinemodebutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Onlinemodebutton);
            this.Controls.Add(this.StoryModebutton);
            this.Controls.Add(this.Oneoptionlabel);
            this.Controls.Add(this.WelcomeLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label WelcomeLabel;
        private System.Windows.Forms.Label Oneoptionlabel;
        private System.Windows.Forms.Button StoryModebutton;
        private System.Windows.Forms.Button Onlinemodebutton;
    }
}

