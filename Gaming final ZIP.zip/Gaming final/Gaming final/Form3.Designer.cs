﻿namespace Gaming_final
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WarriorradioButton = new System.Windows.Forms.RadioButton();
            this.continuebutton = new System.Windows.Forms.Button();
            this.descriptiongroupBox = new System.Windows.Forms.GroupBox();
            this.descriptionlabel = new System.Windows.Forms.Label();
            this.StatsgroupBox = new System.Windows.Forms.GroupBox();
            this.defenselabel = new System.Windows.Forms.Label();
            this.speedlabel = new System.Windows.Forms.Label();
            this.Attacklabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SelectAvatarLabel = new System.Windows.Forms.Label();
            this.MageradioButton = new System.Windows.Forms.RadioButton();
            this.rogueradioButton = new System.Windows.Forms.RadioButton();
            this.healerradioButton = new System.Windows.Forms.RadioButton();
            this.descriptiongroupBox.SuspendLayout();
            this.StatsgroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // WarriorradioButton
            // 
            this.WarriorradioButton.AutoSize = true;
            this.WarriorradioButton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WarriorradioButton.Location = new System.Drawing.Point(19, 140);
            this.WarriorradioButton.Name = "WarriorradioButton";
            this.WarriorradioButton.Size = new System.Drawing.Size(190, 31);
            this.WarriorradioButton.TabIndex = 13;
            this.WarriorradioButton.TabStop = true;
            this.WarriorradioButton.Text = "Warrior/Fighter";
            this.WarriorradioButton.UseVisualStyleBackColor = true;
            this.WarriorradioButton.CheckedChanged += new System.EventHandler(this.WarriorradioButton_CheckedChanged);
            // 
            // continuebutton
            // 
            this.continuebutton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.continuebutton.Location = new System.Drawing.Point(615, 36);
            this.continuebutton.Name = "continuebutton";
            this.continuebutton.Size = new System.Drawing.Size(138, 36);
            this.continuebutton.TabIndex = 12;
            this.continuebutton.Text = "Continue";
            this.continuebutton.UseVisualStyleBackColor = true;
            this.continuebutton.Click += new System.EventHandler(this.continuebutton_Click);
            // 
            // descriptiongroupBox
            // 
            this.descriptiongroupBox.Controls.Add(this.descriptionlabel);
            this.descriptiongroupBox.Location = new System.Drawing.Point(250, 122);
            this.descriptiongroupBox.Name = "descriptiongroupBox";
            this.descriptiongroupBox.Size = new System.Drawing.Size(157, 298);
            this.descriptiongroupBox.TabIndex = 11;
            this.descriptiongroupBox.TabStop = false;
            // 
            // descriptionlabel
            // 
            this.descriptionlabel.AutoSize = true;
            this.descriptionlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descriptionlabel.Location = new System.Drawing.Point(6, 18);
            this.descriptionlabel.Name = "descriptionlabel";
            this.descriptionlabel.Size = new System.Drawing.Size(133, 27);
            this.descriptionlabel.TabIndex = 6;
            this.descriptionlabel.Text = "Description:";
            // 
            // StatsgroupBox
            // 
            this.StatsgroupBox.Controls.Add(this.defenselabel);
            this.StatsgroupBox.Controls.Add(this.speedlabel);
            this.StatsgroupBox.Controls.Add(this.Attacklabel);
            this.StatsgroupBox.Controls.Add(this.label2);
            this.StatsgroupBox.Location = new System.Drawing.Point(422, 122);
            this.StatsgroupBox.Name = "StatsgroupBox";
            this.StatsgroupBox.Size = new System.Drawing.Size(359, 298);
            this.StatsgroupBox.TabIndex = 10;
            this.StatsgroupBox.TabStop = false;
            // 
            // defenselabel
            // 
            this.defenselabel.AutoSize = true;
            this.defenselabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.defenselabel.Location = new System.Drawing.Point(7, 154);
            this.defenselabel.Name = "defenselabel";
            this.defenselabel.Size = new System.Drawing.Size(303, 27);
            this.defenselabel.TabIndex = 7;
            this.defenselabel.Text = "Defense (Armor/Resistance):";
            // 
            // speedlabel
            // 
            this.speedlabel.AutoSize = true;
            this.speedlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.speedlabel.Location = new System.Drawing.Point(7, 223);
            this.speedlabel.Name = "speedlabel";
            this.speedlabel.Size = new System.Drawing.Size(287, 27);
            this.speedlabel.TabIndex = 8;
            this.speedlabel.Text = "Speed (Agility/Movement):";
            // 
            // Attacklabel
            // 
            this.Attacklabel.AutoSize = true;
            this.Attacklabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Attacklabel.Location = new System.Drawing.Point(6, 88);
            this.Attacklabel.Name = "Attacklabel";
            this.Attacklabel.Size = new System.Drawing.Size(286, 27);
            this.Attacklabel.TabIndex = 6;
            this.Attacklabel.Text = "Attack (Strength/Damage):";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 27);
            this.label2.TabIndex = 5;
            this.label2.Text = "Health (HP):";
            // 
            // SelectAvatarLabel
            // 
            this.SelectAvatarLabel.AutoSize = true;
            this.SelectAvatarLabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectAvatarLabel.Location = new System.Drawing.Point(251, 30);
            this.SelectAvatarLabel.Name = "SelectAvatarLabel";
            this.SelectAvatarLabel.Size = new System.Drawing.Size(275, 37);
            this.SelectAvatarLabel.TabIndex = 9;
            this.SelectAvatarLabel.Text = "Select Your Avatar";
            // 
            // MageradioButton
            // 
            this.MageradioButton.AutoSize = true;
            this.MageradioButton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MageradioButton.Location = new System.Drawing.Point(19, 210);
            this.MageradioButton.Name = "MageradioButton";
            this.MageradioButton.Size = new System.Drawing.Size(171, 31);
            this.MageradioButton.TabIndex = 14;
            this.MageradioButton.TabStop = true;
            this.MageradioButton.Text = "Mage/Wizard";
            this.MageradioButton.UseVisualStyleBackColor = true;
            this.MageradioButton.CheckedChanged += new System.EventHandler(this.MageradioButton_CheckedChanged);
            // 
            // rogueradioButton
            // 
            this.rogueradioButton.AutoSize = true;
            this.rogueradioButton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rogueradioButton.Location = new System.Drawing.Point(19, 276);
            this.rogueradioButton.Name = "rogueradioButton";
            this.rogueradioButton.Size = new System.Drawing.Size(196, 31);
            this.rogueradioButton.TabIndex = 15;
            this.rogueradioButton.TabStop = true;
            this.rogueradioButton.Text = "Rogue/Assasion";
            this.rogueradioButton.UseVisualStyleBackColor = true;
            this.rogueradioButton.CheckedChanged += new System.EventHandler(this.rogueradioButton_CheckedChanged);
            // 
            // healerradioButton
            // 
            this.healerradioButton.AutoSize = true;
            this.healerradioButton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.healerradioButton.Location = new System.Drawing.Point(19, 341);
            this.healerradioButton.Name = "healerradioButton";
            this.healerradioButton.Size = new System.Drawing.Size(188, 31);
            this.healerradioButton.TabIndex = 16;
            this.healerradioButton.TabStop = true;
            this.healerradioButton.Text = "Healer/Support";
            this.healerradioButton.UseVisualStyleBackColor = true;
            this.healerradioButton.CheckedChanged += new System.EventHandler(this.healerradioButton_CheckedChanged);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.healerradioButton);
            this.Controls.Add(this.rogueradioButton);
            this.Controls.Add(this.MageradioButton);
            this.Controls.Add(this.WarriorradioButton);
            this.Controls.Add(this.continuebutton);
            this.Controls.Add(this.descriptiongroupBox);
            this.Controls.Add(this.StatsgroupBox);
            this.Controls.Add(this.SelectAvatarLabel);
            this.Name = "Form3";
            this.Text = "Form3";
            this.descriptiongroupBox.ResumeLayout(false);
            this.descriptiongroupBox.PerformLayout();
            this.StatsgroupBox.ResumeLayout(false);
            this.StatsgroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RadioButton WarriorradioButton;
        private System.Windows.Forms.Button continuebutton;
        private System.Windows.Forms.GroupBox descriptiongroupBox;
        private System.Windows.Forms.Label descriptionlabel;
        private System.Windows.Forms.GroupBox StatsgroupBox;
        private System.Windows.Forms.Label defenselabel;
        private System.Windows.Forms.Label speedlabel;
        private System.Windows.Forms.Label Attacklabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label SelectAvatarLabel;
        private System.Windows.Forms.RadioButton MageradioButton;
        private System.Windows.Forms.RadioButton rogueradioButton;
        private System.Windows.Forms.RadioButton healerradioButton;
    }
}